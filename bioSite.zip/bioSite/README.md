# CSD 340 Web Development with HTML and CSS

## Contributors

- Instructor: Mrs. Sue Sampson
- Dallas Baldwin

## bioSite

This repository contains the three-page Jennifer Baldwin bioSite:

- `index.html` - landing page
- `about.html` - biography and career/education page
- `hobbies.html` - interests and hobbies page
- `styles.css` - shared site stylesheet
- `images/` - project image assets
