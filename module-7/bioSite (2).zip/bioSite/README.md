# CSD 340 Web Development with HTML and CSS

## Contributors

- Instructor: Mrs. Sue Sampson
- Dallas Baldwin

## bioSite

- `index.html` - landing page
- `contact.html` - contact page and contact form layout
- `hobbies.html` - hobbies and interests page
- `styles.css` - shared site stylesheet
- `images/` - project image assets
